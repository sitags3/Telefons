#include "Funkcijas.h"

void showcursor(bool parbaude)      //iesledz/izsledz cursor
{
   HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
   CONSOLE_CURSOR_INFO info;
   info.dwSize = 10;
   info.bVisible = parbaude;
   SetConsoleCursorInfo(consoleHandle, &info);
}

void textcolor(unsigned short color)    //nomaina teksta krasu
{
    HANDLE hcon = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hcon,color);
}

string rndCipars() //Tiek izveidots nejauss numurs no 0-9
{
    int rnd;
    string line;
    stringstream convert;
    rnd = rand() % 10;
    convert << rnd;
    line = convert.str();
    return line;
}

bool pressedKey(int x, int *pagaidu) //parbauda kura poga nospiesta
{
    do{
        if (_kbhit())
        {
            switch (_getch())
            {
                case 72://up
                    if(*pagaidu == 1){
                        *pagaidu = x;
                    }else{
                        *pagaidu -= 1;
                    }
                    return false;
                case 80://down
                    if(*pagaidu == x){
                        *pagaidu = 1;
                    }else{
                        *pagaidu += 1;
                    }
                    return false;
                case 0x0D: //enter
                    return true;
            }
        }
    }while(*pagaidu<100); // bezgaligs loop
}

bool checkNumurs(string numurs,  string mansNumurs) // Kontaktu vārdiem galā pieliek atstarpes dizaina iemeslu dēļ
{
    fstream telFile;
    telFile.open("Lietotaji\\"+numurs+"\\"+numurs+".txt");
    if(telFile.peek() == ifstream::traits_type::eof()){
        telFile.close();
        remove(("Lietotaji\\"+numurs).c_str());
        return false;
    }else if(numurs == mansNumurs){
        return false;
    }else{
        return true;
    }
}

void atstarpjuPievienosana(string *teksts)
{
    int skaits, atlikums;
    string pagaidu;

    pagaidu = *teksts;
    skaits = pagaidu.length();
    atlikums = 21 - skaits;
    for(int i=0; i<atlikums; i++){
        *teksts+=" ";
    }
}
