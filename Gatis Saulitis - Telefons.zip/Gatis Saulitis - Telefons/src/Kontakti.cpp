#include "Kontakti.h"

Kontakti::Kontakti()
{
    //ctor
}

Kontakti::~Kontakti()
{
    //dtor
}

Kontakti::Kontakti(string vards, string numurs, string telNumurs)
{
    setVards(vards);
    setNumurs(numurs, telNumurs);
}

void Kontakti::izvelne(const string telNumurs) //Sadaļas "Kontakti" galvenā izvelne
{
    string path, vards, numurs, line;
    int izvele;
    bool atkartot, boolIzvele;

    path = "Lietotaji\\"+telNumurs+"\\Kontakti";
    CreateDirectory(path.c_str(),NULL);
    telFile.open(path+"\\kontakti.txt", ios::app | ios::in | ios::out);
    while(!telFile.eof()){
        numurs = " ";
        getline(telFile, line);
        vards = line;
        getline(telFile, line);
        numurs = line;
        if(numurs.length()<3) break;
        Kontakti *jaunsKontakts = new Kontakti(vards, numurs, telNumurs);
        myVector.push_back (jaunsKontakts);
    }
    telFile.close();

    atkartot = true;
    izvele = 0;
    do{
        izvele = 1;
        do{
            Sleep(30);
            boolIzvele = this->drawMenu(&izvele);
        }while(!boolIzvele);

        //izvele
        if(izvele == 1) this->izveidotKontaktu(telNumurs);
        if(izvele == 2) atkartot = false;
        if(izvele > 2){
            this->profils(izvele-3, telNumurs);
        }
    }while(atkartot);
    myVector.erase(myVector.begin(), myVector.end());
}

bool Kontakti::drawMenu(int *izvele) // Kontaktu izvelnes zīmēšana
{
    int pagaidu, idSkaits;
    bool atgriezt;
    string teksts;

    idSkaits = myVector.size();
    system("cls");
    cout << endl;
    cout << endl;
    textcolor(2);
    cout << "     _______________________________________________" << endl;
    cout << "     |                                             |" << endl;
    cout << "     |                   Kontakti                  |" << endl;
    cout << "     |                                             |" << endl;
    cout << "     |                                             |" << endl;

    if((idSkaits>10) && (*izvele>6)){
        int i;

        if((idSkaits-*izvele)<3){
            pagaidu = idSkaits+2;
            i = idSkaits - 9;
        }else{
            i = *izvele-6;
            pagaidu = *izvele+5;
        }
        if(*izvele == 7){
            cout << "     |         ";
            textcolor(3);
            cout << "Atpakal";
            textcolor(2);
            cout << "                             |" << endl;
            pagaidu--;
        }else if(*izvele >= 8){
            i--;
            pagaidu--;
        }
        for(i;  i<pagaidu; i++){
            cout << "     |         ";
            if((i+2) == *izvele) textcolor(4);
            teksts = myVector[i-1]->getVards();
            atstarpjuPievienosana(&teksts);
            cout << teksts;
            textcolor(2);
            cout << "               |" << endl;
        }
        for(int i=0; i<7; i++){
            cout << "     |                                             |" << endl;
        }
        cout << "     |_____________________________________________|" << endl;

        pagaidu = *izvele;
        atgriezt = pressedKey(idSkaits+2, &pagaidu);
        *izvele = pagaidu;
        return atgriezt;

    }else{
        if(idSkaits>10){
            pagaidu = 7;
        }else{
            pagaidu = 17-idSkaits;
        }
        cout << "     |         ";
        if(*izvele == 1){
            textcolor(4);
        }else{
            textcolor(3);
        }
        cout << "Izveidot kontaktu";
        textcolor(2);
        cout << "                   |" << endl;
        cout << "     |         ";
        if(*izvele == 2){
            textcolor(4);
        }else{
            textcolor(3);
        }
        cout << "Atpakal";
        textcolor(2);
        cout << "                             |" << endl;
        for(int i=1; i<(idSkaits+1); i++){
            cout << "     |         ";
            if(*izvele == i+2) textcolor(4);
            teksts = myVector[i-1]->getVards();
            atstarpjuPievienosana(&teksts);
            cout << teksts;
            textcolor(2);
            cout << "               |" << endl;
            if(i==9) break;
        }
        for(int i=0; i<pagaidu; i++){
            cout << "     |                                             |" << endl;
        }
        cout << "     |_____________________________________________|" << endl;

        pagaidu = *izvele;
        atgriezt = pressedKey(idSkaits+2, &pagaidu);
        *izvele = pagaidu;
        return atgriezt;
    }
}

void Kontakti::izveidotKontaktu(string telNumurs) //Izveido jaunu kontaktu priekš konkrētā lietotāja
{
    bool parbaude = false;
    string pagaidu, pagaidu2;

    system("cls");
    cout << endl;
    cout << "   |---------------------------------------------------|" << endl;
    cout << "     Telefona numurs: ";
    showcursor(true);
    textcolor(4);
    cin >> pagaidu;
    textcolor(2);
    parbaude = checkNumurs(pagaidu, telNumurs);
    if(!parbaude){
        showcursor(false);
        cout << endl;
        textcolor(4);
        cout << "Sads numurs neeksiste." << endl;
        textcolor(2);
        system("pause");
    }else{
        cout << "     Vards: ";
        textcolor(4);
        cin >> ws;
        getline(cin, pagaidu2);
        textcolor(2);
        showcursor(false);
        if(pagaidu2.length()>21){
            cout << endl;
            textcolor(4);
            cout << "Vards ir parak gars." << endl;
            textcolor(2);
            system("pause");
        }else{
            testFile.open("Lietotaji\\"+telNumurs+"\\Kontakti\\kontakti.txt", ios::app | ios::in | ios::out);
            testFile << pagaidu2 << endl;
            testFile << pagaidu << endl;
            testFile.close();
            Kontakti *jaunsKontakts = new Kontakti(pagaidu2, pagaidu, telNumurs);
            myVector.push_back (jaunsKontakts);
            cout << endl;
            cout << "Jauns kontakts veiksmigi izveidots!" << endl;
            system("pause");
        }
    }
}

void Kontakti::profils(int id, string telNumurs) // Kontakta profila menu
{
    int izvele;
    bool atkartot, boolIzvele;
    string vards, num;

    atkartot = true;

    do{
        izvele = 1;
        do{
            Sleep(30);
            //izvelne
            system("cls");
            cout << endl;
            cout << endl;
            cout << "     _______________________________________________" << endl;
            cout << "     |                                             |" << endl;
            cout << "     |            ";
            textcolor(3);
            cout << myVector[id]->getVards();
            textcolor(2);
            cout << "                 |" << endl;
            cout << "     |                                             |" << endl;
            cout << "     |         ";
            if(izvele == 1) textcolor(4);
            cout << "Iszinas";
            textcolor(2);
            cout << "                             |" << endl;
            cout << "     |         ";
            if(izvele == 2) textcolor(4);
            cout << "Rediget kontaktu";
            textcolor(2);
            cout << "                    |" << endl;
            cout << "     |         ";
            if(izvele == 3) textcolor(4);
            cout << "Izdzest kontaktu";
            textcolor(2);
            cout << "                    |" << endl;
            cout << "     |         ";
            if(izvele == 4) textcolor(4);
            cout << "Atpakal";
            textcolor(2);
            cout << "                             |" << endl;
            for(int i=1; i<16; i++){
                cout << "     |                                             |" << endl;
            }
            cout << "     |_____________________________________________|" << endl;

            boolIzvele = pressedKey(4, &izvele);
        }while(!boolIzvele);

        switch(izvele){
            case 1:
                //iszinas
                num = myVector[id]->getNumurs();
                vards = myVector[id]->getVards();
                i->sarakste(telNumurs, num, vards);
                break;
            case 2:
                //rediget
                this->redigetVardu(id, telNumurs);
                break;
            case 3:
                //izdzest
                this->izdzestKontaktu(id, telNumurs);
                atkartot = false;
                break;
            case 4:
                //atpakal
                atkartot = false;
                break;
        }
    }while(atkartot);
}

void Kontakti::redigetVardu(int id, string telNumurs) // Iespēja nomainīt kontakta vārdu
{
    string vards, line1, line2, path;
    int idSkaits;

    system("cls");
    cout << endl;
    cout << "   |---------------------------------------------------|" << endl;
    cout << "     Ievadiet jauno vardu: ";
    showcursor(true);
    textcolor(4);
    cin >> ws;
    getline(cin, vards);
    showcursor(false);
    textcolor(2);
    myVector[id]->setVards(vards);
    path = "Lietotaji\\"+telNumurs+"\\Kontakti\\kontakti.txt";
    remove(path.c_str());
    telFile.open("Lietotaji\\"+telNumurs+"\\Kontakti\\kontakti.txt", ios::app | ios::in | ios::out);
    idSkaits = myVector.size();
    for(int i = 0; i<idSkaits; i++){
        line1 = myVector[i]->getVards();
        line2 = myVector[i]->getNumurs();
        telFile << line1 << endl;
        telFile << line2 << endl;
    }
    telFile.close();
    cout << "     Kontakta vards veiksmigi nomainits!" << endl;
    system("pause");
}

void Kontakti::izdzestKontaktu(int id, string telNumurs) // Kontakta dzēšana
{
    bool parbaude;
    int idSkaits;
    int izvele = 1;
    string path = "Lietotaji\\"+telNumurs+"\\Kontakti\\kontakti.txt";
    string line1, line2;

    do{
        Sleep(30);
        system("cls");
        cout << endl;
        cout << "     _______________________________________________" << endl;
        cout << "     |                                             |" << endl;
        cout << "     |     ";
        textcolor(3);
        cout << "Vai velaties izdzest kontaktu?";
        textcolor(2);
        cout << "          |" << endl;
        cout << "     |                                             |" << endl;
        cout << "     |                                             |" << endl;
        cout << "     |                     ";
        if(izvele == 1) textcolor(4);
        cout << "JA";
        textcolor(2);
        cout << "                      |" << endl;
        cout << "     |                     ";
        if(izvele == 2) textcolor(4);
        cout << "NE";
        textcolor(2);
        cout << "                      |" << endl;
        for(int i = 0; i<18; i++){
            cout << "     |                                             |" << endl;
        }
        cout << "     |_____________________________________________|" << endl;

        parbaude = pressedKey(2, &izvele);
    }while(!parbaude);

    if(izvele == 1){
        myVector.erase(myVector.begin()+id);
        remove(path.c_str());
        telFile.open("Lietotaji\\"+telNumurs+"\\Kontakti\\kontakti.txt", ios::app | ios::in | ios::out);
        idSkaits = myVector.size();
        for(int i = 0; i<idSkaits; i++){
            line1 = myVector[i]->getVards();
            line2 = myVector[i]->getNumurs();
            telFile << line1 << endl;
            telFile << line2 << endl;
        }
        telFile.close();
        cout << "Kontakts ir veiksmigi izdzests!" << endl;
        system("pause");
    }
}
