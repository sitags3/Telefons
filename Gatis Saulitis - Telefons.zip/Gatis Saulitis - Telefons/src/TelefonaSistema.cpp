#include "TelefonaSistema.h"

TelefonaSistema::TelefonaSistema()
{
    showcursor(false);
    CreateDirectory("Lietotaji",NULL);
    this->Izvelne();
    //ctor
}

TelefonaSistema::~TelefonaSistema()
{
    //dtor
}

void TelefonaSistema::Izvelne() //Programmas galvenais menu
{
    int izvele;
    bool atkartot;
    bool boolIzvele;

    atkartot = true;

    do{
        izvele = 1;
        do{
            Sleep(30);
            boolIzvele = this->drawMenu(&izvele);
        }while(boolIzvele == false);

        switch(izvele){
            case 1:
                //pieslegties telefonam
                l->pieslegties();
                break;
            case 2:
                //Izveidot telefonu
                l->izveidotLietotaju();
                break;
            case 3:
                atkartot=false;
                break;
        }
    }while(atkartot);
}

bool TelefonaSistema::drawMenu(int *izvele)      // uzzime main menu
{
    bool atgriezt;
    int pagaidu;

    system("cls");
    cout << endl;
    cout << endl;
    textcolor(2);
    cout << "   _______________________________" << endl;
    cout << "   |                             |" << endl;
    cout << "   |  ";
    if(*izvele == 1) textcolor(4);
    cout << "Pieslegties telefonam";
    textcolor(2);
    cout << "      |" << endl;
    cout << "   |  ";
    if(*izvele == 2) textcolor(4);
    cout << "Izveidot telefonu";
    textcolor(2);
    cout << "          |" << endl;
    cout << "   |  ";
    if(*izvele == 3) textcolor(4);
    cout << "Izslegt programmu";
    textcolor(2);
    cout << "          |" << endl;
    cout << "   |_____________________________|" << endl;

    pagaidu = *izvele;
    atgriezt = pressedKey(3, &pagaidu);
    *izvele = pagaidu;
    return atgriezt;
}

