#include "Telefons.h"

Telefons::Telefons()
{
    //ctor
}

Telefons::~Telefons()
{
    //dtor
}

Telefons::Telefons(string num)
{
    const string telNumurs = num;
    this->izvelne(telNumurs);
}

void Telefons::izvelne(const string telNumurs) //Telefona galvenā izvelne
{
    int izvele;
    bool atkartot, boolIzvele;
    textcolor(2);

    atkartot = true;
    do{
        izvele = 1;
        do{
            Sleep(30);
            boolIzvele = this->drawMenu(&izvele);
        }while(!boolIzvele);

        switch(izvele){
            case 1:
                //Kontakti
                k->izvelne(telNumurs);
                break;
            case 2:
                //Izzinas
                i->izvelne(telNumurs);
                break;
            case 3:
                //Setingi
                s->izvelne(telNumurs);
                break;
            case 4:
                //izslegt telefonu
                atkartot = false;
                break;
        }
    }while(atkartot);
}

bool Telefons::drawMenu(int *izvele) //uzzīmē telefona izvelni
{
    int pagaidu;
    bool atgriezt;

    system("cls");
    cout << endl;
    cout << endl;
    textcolor(2);
    cout << "     _______________________________________________" << endl;
    cout << "     |                                             |" << endl;
    cout << "     |         ";
    if(*izvele == 1) textcolor(4);
    cout << "Kontakti";
    textcolor(2);
    cout << "                            |" << endl;
    cout << "     |         ";
    if(*izvele == 2) textcolor(4);
    cout << "Iszinas";
    textcolor(2);
    cout << "                             |" << endl;
    cout << "     |         ";
    if(*izvele == 3) textcolor(4);
    cout << "Iestatijumi";
    textcolor(2);
    cout << "                         |" << endl;
    cout << "     |         ";
    if(*izvele == 4) textcolor(4);
    cout << "Izslegt telefonu";
    textcolor(2);
    cout << "                    |" << endl;
    for(int i=1; i<18; i++){
        cout << "     |                                             |" << endl;
    }
    cout << "     |_____________________________________________|" << endl;

    pagaidu = *izvele;
    atgriezt = pressedKey(4, &pagaidu);
    *izvele = pagaidu;
    return atgriezt;
}
