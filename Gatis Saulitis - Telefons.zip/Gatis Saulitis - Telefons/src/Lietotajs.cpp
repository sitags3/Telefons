#include "Lietotajs.h"

Lietotajs::Lietotajs()
{
    //ctor
}

Lietotajs::~Lietotajs()
{
    //dtor
}

void Lietotajs::izveidotLietotaju() //Izveido jaunu failu kura saglaba informaciju par profilu
{

    string pagaiduString;
    string path;

    system("cls");
    srand(time(NULL));

    pagaiduString = this->numuraIzveide();
    path = "Lietotaji\\"+pagaiduString;
    CreateDirectory(path.c_str(),NULL);
    telFile.open("Lietotaji\\"+pagaiduString+"\\"+pagaiduString+".txt", ios::app | ios::in | ios::out);
    telFile << pagaiduString << endl;

    pagaiduString = this->pinIzveide();
    telFile << pagaiduString << endl;

    cout << endl;
    cout << "------Telefona izveide------" << endl;
    cout << endl;

    cout << "   Vards: ";
    textcolor(4);
    showcursor(true);
    cin >> ws;
    getline(cin, pagaiduString);
    showcursor(false);
    textcolor(2);
    telFile << pagaiduString << endl;

    cout << "   Uzvards: ";
    textcolor(4);
    showcursor(true);
    cin >> ws;
    getline(cin, pagaiduString);
    showcursor(false);
    textcolor(2);
    telFile << pagaiduString << endl;

    Sleep(100);
    system("cls");
    cout << endl;
    cout << "--------------------------------------------------------------------------" << endl;
    textcolor(3);
    cout << " Atcerieties telefona numuru un pin kodu lai varetu pieslegties telefonam." << endl;
    textcolor(2);
    cout << endl;
    telFile.seekp(0);
    cout << "Telefona numurs: ";
    getline(telFile, pagaiduString);
    cout << pagaiduString << endl;
    cout << "Pin kods: ";
    getline(telFile, pagaiduString);
    cout << pagaiduString << endl;
    cout << endl;
    telFile.close();
    system("pause");
}

string Lietotajs::numuraIzveide() //Tiek izveidots nejaušs numurs kurš nevar būt vienāds ar kādu citu eksistējošu numuru
{
    string line;
    string pagaiduString;
    string path;
    bool parbaude;

    do{
        pagaiduString = "26";
        for(int i=0; i<6; i++){
            line = rndCipars();
            pagaiduString += line;
        }
        path = "Lietotaji\\"+pagaiduString;
        CreateDirectory(path.c_str(),NULL);
        telFile.open("Lietotaji\\"+pagaiduString+"\\"+pagaiduString+".txt", ios::app | ios::in | ios::out);
        if(telFile.peek() == ifstream::traits_type::eof()){
            telFile.close();
            remove(("Lietotaji\\"+pagaiduString).c_str());
            parbaude = false;
        }else{
            parbaude = true;
        }
    }while(parbaude);
    return pagaiduString;
}

string Lietotajs::pinIzveide() //izveido nejausu 4 ciparu kombinaciju
{
    string line;
    string pagaiduString;
    pagaiduString = "";
    for(int i=0; i<4; i++){
        line = rndCipars();
        pagaiduString += line;
    }
    return pagaiduString;
}

void Lietotajs::pieslegties() //Lietotājs pieslēdzas savam profilam
{
    fstream telefons;
    string ievadeNum, ievadePin, pinParbaude;

    system("cls");
    textcolor(2);
    cout << endl;
    cout << "   |---------------------------------------------------|" << endl;
    cout << "     Telefona numurs: ";
    textcolor(4);
    showcursor(true);
    cin >> ievadeNum;
    textcolor(2);
    cout << "     Pin: ";
    textcolor(4);
    cin >> ievadePin;
    showcursor(false);

    telefons.open("Lietotaji\\"+ievadeNum+"\\"+ievadeNum+".txt");
    getline(telefons, pinParbaude);
    getline(telefons, pinParbaude);

    if(telefons.peek() == ifstream::traits_type::eof()){
        telefons.close();
        remove(("Lietotaji\\"+ievadeNum).c_str());
        cout << endl;
        textcolor(4);
        cout << "     Nepareizi ievadits telefona numurs vai pin kods." << endl;
        textcolor(2);
        system("pause");
    }else if(pinParbaude != ievadePin){
        telefons.close();
        cout << endl;
        textcolor(4);
        cout << "     Nepareizi ievadits telefona numurs vai pin kods." << endl;
        textcolor(2);
        system("pause");
    }else{
        telefons.close();
        Telefons *t = new Telefons(ievadeNum);
        delete t;
    }
}

