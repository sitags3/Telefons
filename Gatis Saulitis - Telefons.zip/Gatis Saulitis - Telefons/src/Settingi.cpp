#include "Settingi.h"

Settingi::Settingi()
{
    //ctor
}

Settingi::~Settingi()
{
    //dtor
}

void Settingi::izvelne(string mansNumurs) // Sadaļas "settingi" galvenā izvelne
{
    int izvele;
    bool atkartot, boolIzvele;
    textcolor(2);

    atkartot = true;
    do{
        izvele = 1;
        do{
            Sleep(30);
            boolIzvele = this->drawMenu(&izvele);
        }while(!boolIzvele);

        switch(izvele){
            case 1:
                //mainit pin
                this->mainitPIN(mansNumurs);
                break;
            case 2:
                //atpakal
                atkartot = false;
                break;
        }
    }while(atkartot);
}

bool Settingi::drawMenu(int *izvele) // settingu izvelnes zīmēšana
{
    int pagaidu;
    bool atgriezt;

    system("cls");
    cout << endl;
    cout << endl;
    textcolor(2);
    cout << "     _______________________________________________" << endl;
    cout << "     |                                             |" << endl;
    cout << "     |         ";
    if(*izvele == 1) textcolor(4);
    cout << "Mainit PIN kodu";
    textcolor(2);
    cout << "                     |" << endl;
    cout << "     |         ";
    if(*izvele == 2) textcolor(4);
    cout << "Atpakal";
    textcolor(2);
    cout << "                             |" << endl;
    for(int i=1; i<20; i++){
        cout << "     |                                             |" << endl;
    }
    cout << "     |_____________________________________________|" << endl;

    pagaidu = *izvele;
    atgriezt = pressedKey(2, &pagaidu);
    *izvele = pagaidu;
    return atgriezt;
}

void Settingi::mainitPIN(string mansNumurs) //Lietotāja PIN koda mainīšana
{
    string pinIevade1, pinIevade2, line, vecaisPIN, path, path2;
    path = "Lietotaji\\"+mansNumurs+"\\"+mansNumurs+".txt";
    path2 = "Lietotaji\\"+mansNumurs+"\\pagaidu.txt";

    system("cls");
    cout << "      |----------------------------------------------------------------|" << endl;
    cout << endl;
    cout << "       Ievadiet veco PIN kodu: ";
    textcolor(4);
    showcursor(true);
    cin >> vecaisPIN;
    textcolor(2);
    cout << endl;
    cout << "       Ievadiet jauno PIN kodu: ";
    textcolor(4);
    cin >> pinIevade1;
    textcolor(2);
    cout << "       Atkartojiet jauno PIN kodu: ";
    textcolor(4);
    cin >> pinIevade2;
    showcursor(false);
    textcolor(2);
    cout << endl;

    telFile.open(path.c_str(), ios::app | ios::in | ios::out);
    getline(telFile, line);
    getline(telFile, line);
    if(line == vecaisPIN){
        if(pinIevade1 == pinIevade2){
            telFile2.open(path2.c_str(), ios::app | ios::in | ios::out);
            telFile2 << mansNumurs << endl;
            telFile2 << pinIevade1 << endl;
            getline(telFile, line);
            telFile2 << line << endl;
            getline(telFile, line);
            telFile2 << line << endl;
            telFile.close();
            telFile2.close();
            remove(path.c_str());
            rename(path2.c_str(), path.c_str());
            cout << "       PIN kods veiksmigi nomainits!" << endl;
            system("pause");
        }else{
            cout << "       Jaunas paroles nesakrit!" << endl;
            system("pause");
        }
    }else{
        cout << "       Nepareizs vecais PIN kods!" << endl;
        system("pause");
    }
}
