#include "Iszinas.h"

Iszinas::Iszinas()
{
    //ctor
}

Iszinas::Iszinas(int id, string teksts)
{
    setTeksts(teksts);
    setID(id);
}

Iszinas::~Iszinas()
{
    //dtor
}

void Iszinas::sarakste(string mansNumurs, string otrsNumurs, string vards) // Tiek atvērta sarakste starp diviem lietotājiem
{
    string path, line, teksts;
    int id, idSkaits, izvele, iszinuIzvele, pagaidu;
    bool atkartot, boolIzvele;

    system("cls");
    path = "Lietotaji\\"+mansNumurs+"\\Iszinas";
    CreateDirectory(path.c_str(),NULL);
    telFile.open(path+"\\"+otrsNumurs+".txt", ios::app | ios::in | ios::out);
    while(!telFile.eof()){
        getline(telFile, line);
        id = atoi(line.c_str());
        getline(telFile, line);
        teksts = line;
        Iszinas *jaunaIszina = new Iszinas(id, teksts);
        iszinuSarakste.push_back(jaunaIszina);
    }
    iszinuSarakste.pop_back();
    telFile.close();

    idSkaits = iszinuSarakste.size();
    pagaidu = idSkaits;
    atkartot = true;
    izvele = 1;
    do{
        do{
            Sleep(30);
            system("cls");
            cout << endl;
            cout << "       Sarakste ar ";
            textcolor(7);
            cout << vards << endl;
            textcolor(2);
            cout << endl;
            cout << "      |----------------------------------------------------------------|" << endl;
            cout << endl;
            if(idSkaits<5){
                if(!idSkaits){
                    cout << "           Sarakste ir tuksa!" << endl;
                }
                for(int i=0; i<idSkaits; i++){
                    if(iszinuSarakste[i]->getID()){
                        textcolor(1);
                        cout << "       Tu: " << iszinuSarakste[i]->getTeksts() << endl;
                    }else{
                        textcolor(7);
                        cout << "       " << vards << ": ";
                        cout << iszinuSarakste[i]->getTeksts() << endl;
                    }
                    cout << endl;
                }
            }else{
                for(int i=pagaidu-4; i<pagaidu; i++){
                    if(iszinuSarakste[i]->getID()){
                        textcolor(1);
                        cout << "       Tu: " << iszinuSarakste[i]->getTeksts() << endl;
                    }else{
                        textcolor(7);
                        cout << "       " << vards << ": ";
                        cout << iszinuSarakste[i]->getTeksts() << endl;
                    }
                    cout << endl;
                }
            }
            textcolor(2);
            cout << "      |----------------------------------------------------------------|" << endl;
            cout << endl;

            if(izvele == 1) textcolor(4);
            cout << "               Rakstit jaunu iszinu" << endl;
            textcolor(2);
            if(izvele == 2) textcolor(4);
            cout << "               Atpakal" << endl;
            textcolor(2);
            if(izvele == 3) textcolor(4);
            cout << "               Uz augsu" << endl;
            textcolor(2);
            if(izvele == 4) textcolor(4);
            cout << "               Uz leju" << endl;
            textcolor(2);

            boolIzvele = pressedKey(4, &izvele);
        }while(!boolIzvele);

        switch(izvele){
            case 1:
                //jauna iszina
                this->rakstitIszinu(mansNumurs, otrsNumurs);
                idSkaits = iszinuSarakste.size();
                pagaidu = idSkaits;
                break;
            case 2:
                //atpakal
                atkartot = false;
                break;
            case 3:
                //uz augsu
                if(pagaidu > 4) pagaidu--;
                break;
            case 4:
                //uz leju
                if(pagaidu < idSkaits) pagaidu++;
                break;
        }
    }while(atkartot);
    iszinuSarakste.erase(iszinuSarakste.begin(), iszinuSarakste.end());
}

void Iszinas::rakstitIszinu(string mansNumurs, string otrsNumurs) // Jaunas īsziņas rakstīšana citam lietotājam
{
    string ievade, path, line;
    bool parbaude;
    fstream myFile;

    system("cls");
    cout << endl;
    cout << "      |----------------------------------------------------------------|" << endl;
    cout << endl;
    showcursor(true);
    cout << "       Ievadiet iszinu (max. 60 simboli): ";
    textcolor(4);
    getline(cin, ievade);
    showcursor(false);
    textcolor(2);
    cout << endl;
    if(ievade.length() > 60){
        textcolor(4);
        cout << "       Iszina ir parak gara." << endl;
        textcolor(2);
        system("pause");
    }else{
        if(ievade == ""){
            cout << "       Tuksu iszinu nevar nosutit!" << endl;
        }else{
            path = "Lietotaji\\"+otrsNumurs+"\\Iszinas\\";
            CreateDirectory(path.c_str(),NULL);
            telFile.open(path+mansNumurs+".txt", ios::app | ios::in | ios::out);
            telFile << "0" << endl;
            telFile << ievade << endl;
            telFile.close();

            myFile.open(path+"iszinuSaraksts.txt", ios::app | ios::in | ios::out);
            parbaude = false;
            while(!myFile.eof()){
                getline(myFile, line);
                if(line == mansNumurs){
                    parbaude = true;
                }
            }
            myFile.close();
            myFile.open(path+"iszinuSaraksts.txt", ios::app | ios::in | ios::out);
            if(!parbaude){
                myFile << mansNumurs << endl;
            }
            myFile.close();

            myFile.open("Lietotaji\\"+mansNumurs+"\\Iszinas\\iszinuSaraksts.txt", ios::app | ios::in | ios::out);
            parbaude = false;
            while(!myFile.eof()){
                getline(myFile, line);
                if(line == otrsNumurs){
                    parbaude = true;
                }
            }
            myFile.close();
            myFile.open("Lietotaji\\"+mansNumurs+"\\Iszinas\\iszinuSaraksts.txt", ios::app | ios::in | ios::out);
            if(!parbaude){
                myFile << otrsNumurs << endl;
            }
            myFile.close();

            telFile.open("Lietotaji\\"+mansNumurs+"\\Iszinas\\"+otrsNumurs+".txt", ios::app | ios::in | ios::out);
            telFile << "1" << endl;
            telFile << ievade << endl;
            telFile.close();
            Iszinas *jaunaIszina = new Iszinas(1, ievade);
            iszinuSarakste.push_back(jaunaIszina);

            cout << "       Iszina veiksmigi nosutita!" << endl;
        }
        system("pause");
    }
}

void Iszinas::izvelne(string mansNumurs) // Sadaļas "Īsziņas" galvenā izvelne
{
    int izvele;
    bool atkartot, boolIzvele, numParbaude;
    string numIevade;

    atkartot = true;
    do{
        izvele = 1;
        do{
            Sleep(30);
            boolIzvele = this->drawMenu(&izvele);
        }while(!boolIzvele);

        switch(izvele){
            case 1:
                //sarakstes
                this->iszinuSaraksts(mansNumurs);
                break;
            case 2:
                //jauna iszina
                system("cls");
                cout << endl;
                cout << "      |----------------------------------------------------------------|" << endl;
                cout << endl;
                cout << "       Ierakstiet telefona numuru kuram rakstit iszinu: ";
                showcursor(true);
                textcolor(4);
                cin >> ws;
                getline(cin, numIevade);
                textcolor(2);
                showcursor(false);
                numParbaude = checkNumurs(numIevade, mansNumurs);
                if(numParbaude){
                    this->rakstitIszinu(mansNumurs, numIevade);
                }else{
                    cout << endl;
                    textcolor(4);
                    cout << "       Sads numurs neeksiste!" << endl;
                    textcolor(2);
                    system("pause");
                }
                break;
            case 3:
                //atpakal
                atkartot = false;
                break;
        }
    }while(atkartot);
}

bool Iszinas::drawMenu(int *izvele) // Īsziņu izvelnes zīmēšana
{
    int pagaidu;
    bool atgriezt;

    system("cls");
    cout << endl;
    cout << endl;
    textcolor(2);
    cout << "     _______________________________________________" << endl;
    cout << "     |                                             |" << endl;
    cout << "     |         ";
    if(*izvele == 1) textcolor(4);
    cout << "Sarakstes";
    textcolor(2);
    cout << "                           |" << endl;
    cout << "     |         ";
    if(*izvele == 2) textcolor(4);
    cout << "Jauna iszina";
    textcolor(2);
    cout << "                        |" << endl;
    cout << "     |         ";
    if(*izvele == 3) textcolor(4);
    cout << "Atpakal";
    textcolor(2);
    cout << "                             |" << endl;
    for(int i=1; i<19; i++){
        cout << "     |                                             |" << endl;
    }
    cout << "     |_____________________________________________|" << endl;

    pagaidu = *izvele;
    atgriezt = pressedKey(3, &pagaidu);
    *izvele = pagaidu;
    return atgriezt;
}

void Iszinas::iszinuSaraksts(string mansNumurs) //Saraksts ar visiem lietotājiem kuri lietotājam vai lietotājs kuriem ir sūtijis īsziņas
{
    string path, line, teksts;
    int id, idSkaits, izvele, pagaidu;
    bool boolIzvele, atkartot;

    system("cls");
    path = "Lietotaji\\"+mansNumurs+"\\Iszinas\\";
    CreateDirectory(path.c_str(),NULL);
    id = 0;
    telFile.open(path+"iszinuSaraksts.txt", ios::app | ios::in | ios::out);
    while(!telFile.eof()){
        id++;
        getline(telFile, line);
        teksts = line;
        Iszinas *sarakstaElements = new Iszinas(id, teksts);
        saraksts.push_back(sarakstaElements);
    }
    saraksts.pop_back();
    telFile.close();

    idSkaits = saraksts.size();
    atkartot = true;
    do{
        izvele = 1;
        do{
            //draw
            Sleep(30);
            system("cls");
            cout << endl;
            cout << "     _______________________________________________" << endl;
            cout << "     |                                             |" << endl;

            if((idSkaits>10) && (izvele>5)){
                int i;

                if((idSkaits-izvele)<5){
                    pagaidu = idSkaits+1;
                    i = idSkaits - 10;
                }else{
                    i = izvele-5;
                    pagaidu = izvele+6;
                }
                for(i;  i<pagaidu; i++){
                    cout << "     |         ";
                    if((i+1) == izvele) textcolor(4);
                    cout << saraksts[i-1]->getTeksts() + "             ";
                    textcolor(2);
                    cout << "               |" << endl;
                }
                for(int i=0; i<11; i++){
                    cout << "     |                                             |" << endl;
                }
                cout << "     |_____________________________________________|" << endl;
            }else{
                if(idSkaits>10){
                    pagaidu = 11;
                }else{
                    pagaidu = 21-idSkaits;
                }
                cout << "     |         ";
                if(izvele == 1){
                    textcolor(4);
                }else{
                    textcolor(3);
                }
                cout << "Atpakal";
                textcolor(2);
                cout << "                             |" << endl;
                for(int i=1; i<(idSkaits+1); i++){
                    cout << "     |         ";
                    if(izvele == i+1) textcolor(4);
                    cout << saraksts[i-1]->getTeksts() + "             ";
                    textcolor(2);
                    cout << "               |" << endl;
                    if(i==10) break;
                }
                for(int i=0; i<pagaidu; i++){
                    cout << "     |                                             |" << endl;
                }
                cout << "     |_____________________________________________|" << endl;
            }
            boolIzvele = pressedKey(idSkaits+1, &izvele);
        }while(!boolIzvele);

        if(izvele == 1){
            //atpakal
            atkartot = false;
        }else{
            line = saraksts[izvele-2]->getTeksts();
            sarakste(mansNumurs, line, line);
        }
    }while(atkartot);
}
