/************************************************************************
* Lai kods strādātu ir jāizmanto compiler versija c++11 vai augstāka.   *
*                                                                       *
************************************************************************/
#include <TelefonaSistema.h>

int main()
{
    TelefonaSistema * tel = new TelefonaSistema;
    delete tel;

    return 0;
}
