#ifndef KONTAKTI_H
#define KONTAKTI_H

#include <iostream>
#include <Funkcijas.h>
#include <Iszinas.h>
#include <fstream>
#include <stdlib.h>
#include <vector>

using namespace std;

class Kontakti
{
    public:
        Kontakti();
        Kontakti(string, string, string);
        virtual ~Kontakti();
        void izvelne(const string);
        bool drawMenu(int *);
        void izveidotKontaktu(string);
        void profils(int, string);
        void redigetVardu(int, string);
        void izdzestKontaktu(int, string);
        fstream telFile;
        fstream testFile;
        vector<Kontakti*> myVector;

        string getNumurs(){
            return numurs;
        }
        string getVards(){
            return vards;
        }

        void setNumurs(string numurs, string telNumurs){
            if(checkNumurs(numurs, telNumurs)){
                this->numurs = numurs;
            }else{
                this->numurs = "666";
            }
        }
        void setVards(string vards){
            this->vards = vards;
        }

    protected:

    private:
        Iszinas *i = new Iszinas;

        string numurs;
        string vards;

};

#endif // KONTAKTI_H
