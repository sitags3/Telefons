#ifndef TELEFONASISTEMA_H
#define TELEFONASISTEMA_H

#include "Lietotajs.h"
#include "Funkcijas.h"
#include <windows.h>
#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>

using namespace std;

class TelefonaSistema
{
    public:
        TelefonaSistema();
        virtual ~TelefonaSistema();
        void Izvelne();
        bool drawMenu(int*);

    protected:

    private:
        Lietotajs  *l = new Lietotajs;
};

#endif // TELEFONASISTEMA_H
