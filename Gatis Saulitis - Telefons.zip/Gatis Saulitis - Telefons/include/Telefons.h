#ifndef TELEFONS_H
#define TELEFONS_H

#include <Funkcijas.h>
#include <Iszinas.h>
#include <Settingi.h>
#include <Kontakti.h>
#include <windows.h>
#include <iostream>
#include <fstream>

using namespace std;

class Telefons
{
    public:
        Telefons();
        virtual ~Telefons();
        Telefons(string);
        void izvelne(const string);
        fstream telFile;
        bool drawMenu(int*);

    protected:

    private:
        Kontakti *k = new Kontakti;
        Settingi *s = new Settingi;
        Iszinas *i = new Iszinas;
};

#endif // TELEFONS_H
