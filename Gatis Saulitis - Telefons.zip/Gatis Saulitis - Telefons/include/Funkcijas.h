#ifndef FUNKCIJAS_H
#define FUNKCIJAS_H

#include <iostream>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <fstream>

using namespace std;

    void showcursor(bool);
    void textcolor(unsigned short);
    string rndCipars();
    bool pressedKey(int, int*);
    bool checkNumurs(string, string);
    void atstarpjuPievienosana(string*);

#endif // FUNKCIJAS_H
