#ifndef LIETOTAJS_H
#define LIETOTAJS_H

#include <Funkcijas.h>
#include <Telefons.h>
#include <iostream>
#include <windows.h>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <ctime>

using namespace std;

class Lietotajs
{
    public:
        Lietotajs();
        virtual ~Lietotajs();
        void izveidotLietotaju();
        void pieslegties();
        string numuraIzveide();
        string pinIzveide();
        fstream telFile;

    protected:

    private:

};

#endif // LIETOTAJS_H
