#ifndef ISZINAS_H
#define ISZINAS_H

#include <iostream>
#include <Funkcijas.h>
#include <fstream>
#include <windows.h>
#include <vector>

using namespace std;

class Iszinas
{
    public:
        Iszinas();
        Iszinas(int, string);
        virtual ~Iszinas();
        void sarakste(string, string, string);
        void rakstitIszinu(string, string);
        void izvelne(string);
        bool drawMenu(int*);
        void iszinuSaraksts(string);
        fstream telFile;
        vector<Iszinas*>saraksts;
        vector<Iszinas*>iszinuSarakste;

        string getTeksts(){
            return teksts;
        }

        int getID(){
            return id;
        }

        void setTeksts(string teksts){
            this->teksts = teksts;
        }

        void setID(int id){
            this->id = id;
        }

    protected:

    private:
        string teksts;
        int id;
};

#endif // ISZINAS_H
