#ifndef SETTINGI_H
#define SETTINGI_H

#include <iostream>
#include <Funkcijas.h>
#include <windows.h>
#include <fstream>

using namespace std;

class Settingi
{
    public:
        Settingi();
        virtual ~Settingi();
        void izvelne(string);
        bool drawMenu(int*);
        void mainitPIN(string);
        fstream telFile;
        fstream telFile2;

    protected:

    private:
};

#endif // SETTINGI_H
